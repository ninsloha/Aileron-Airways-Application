export default function (description) {
  if (!description) return 'Description is required.'
}
