export default function (file) {
  if (!file) return 'File is required.'
}
